import React from "react";

const TeacherLogin = () => {
  return <div>TeacherLogin</div>;
};

export default TeacherLogin;
